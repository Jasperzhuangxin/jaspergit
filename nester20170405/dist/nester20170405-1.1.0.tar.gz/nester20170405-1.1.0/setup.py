from distutils.core import setup

setup(
        name='nester20170405',
        version='1.1.0',
        py_modules=['nester20170405'],
        author='Jasper',
        author_email='jasper.wj@foxmail.com',
        url='https://github.com/Jasperzhuangxin/jaspergit',
        description='A simple printer of nested lists',
	)
