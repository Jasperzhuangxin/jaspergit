from distutils.core import setup

setup(
        name='chapter7',
        version='1.0.0',
        py_modules=['web20170415'],
        author='Jasper',
        author_email='jasper.wj@foxmail.com',
        url='https://github.com/Jasperzhuangxin/jaspergit',
        description='create a web app',
	)
